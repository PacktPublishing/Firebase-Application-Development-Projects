

//get the users display pic
const getProfilePicUrl = () => {
    return auth.currentUser.photoURL || '/images/blank.png';
}


//get a handle on the form
const createMessage = document.querySelector('#chat-form');
createMessage.addEventListener('submit', (e)=>{
    e.preventDefault();
    e.stopPropagation();
    console.log(createMessage.message.value);
    saveMessage(createMessage['message'].value);
    createMessage.reset();
})

//save messages to the firestore
const saveMessage = (messageText) => {
    return fs.collection('messages').add({
        name: auth.currentUser.displayName,
        text: messageText,
        profilePicUrl: getProfilePicUrl(),
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
    }).catch(error =>{
        console.log('Error writing new message to firestore', error);
    })
}



importScripts('https://www.gstatic.com/firebasejs/5.8.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/5.8.1/firebase-messaging.js');

const config = {
    apiKey: "AIzaSyBbKPuFHZEimGk35eNg6wW4e31OWRubQTU",
    authDomain: "packtfirebase.firebaseapp.com",
    databaseURL: "https://packtfirebase.firebaseio.com",
    projectId: "packtfirebase",
    storageBucket: "packtfirebase.appspot.com",
    messagingSenderId: "931488985584"
    };
    firebase.initializeApp(config);


    
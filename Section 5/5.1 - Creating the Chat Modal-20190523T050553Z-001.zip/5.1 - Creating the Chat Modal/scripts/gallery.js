//function to store image data in the firestore
const storeImages = (user, url, fileName)=>{
    fs.collection('galleryUploads').add({
        imageUrl: `${url}`,
        uploadedBy: `${user.displayName}`,
        fileName: `galleryUploads/${fileName}`,
    }).then(()=>{
        console.log('image data added to the firestore');
    }).catch(error=>{
        console.log("Error uploading image data:", error);
    })
}


//handle uploaded files
const uploadedFile = document.querySelector('#galleryFile');
uploadedFile.addEventListener('change', (e)=>{
    e.stopPropagation();
    e.preventDefault();
    const file = e.target.files[0];
    console.log(file);
    const metadata = {'contentType': file.type};

    storageRef.child('galleryUploads/' + file.name)
        .put(file, metadata)
        .then((snapshot)=>{
            console.log(snapshot.bytesTransferred);
            console.log('Uploaded:', snapshot.totalBytes, 'bytes')

            snapshot.ref.getDownloadURL().then(url=>{
                console.log('File available at', url);
                storeImages(auth.currentUser, url, file.name)
            }).catch(error=>{
                console.log("Error getting download url:", error);
            })

        })
})


const gallery = document.querySelector('.gallery');

const setupGallery = (data)=>{
    if(data.length){
        let html='';
        data.forEach(doc =>{
            const image = doc.data();

            const div=`
            <div id="${doc.id}">
            <img src="${image.imageUrl}" width="40%" />
            <p> Uploaded by: <br>${image.uploadedBy}</p>
            <div id="${image.fileName}" class="btn red z-depth-0 deleteImage">Delete</div>
            <br/>
            <div>
            
            `;
            html += div;
        })

        gallery.innerHTML = html;

        const deleteButtons = document.querySelectorAll('.deleteImage');
        deleteButtons.forEach(deleteButton=>{
            auth.currentUser.getIdTokenResult().then(idTokenResult=>{
                if(idTokenResult.claims.admin){
                    deleteButton.style.display="block"
                }else{
                    deleteButton.style.display="none"
                }
            })

            deleteButton.addEventListener('click', (e)=>{
                e.preventDefault();
                let id = e.target.parentElement.getAttribute('id');
               
                fs.collection('galleryUploads')
                .doc(id)
                .delete();

                storageRef.child(deleteButton['id']).delete().then(()=>{
                    console.log('File deleted from cloud storage')
                }).catch(error=>{
                    console.log("Error deleting file from cloud storage:", error);
                })
                



                


            })


        })







    }else{
        gallery.innerHTML = '<h6 class="center-align">There are no Photos!</h6>';
    }
}
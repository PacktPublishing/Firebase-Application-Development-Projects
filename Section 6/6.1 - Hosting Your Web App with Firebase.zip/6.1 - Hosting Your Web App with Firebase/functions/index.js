const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

exports.makeAdmin = functions.https.onCall((data, context)=>{
    return admin.auth().getUserByEmail(data.email).then(user =>{

        if(data.email === 'vic@packt.com' || data.email === 'wooding@packt.com'){
            message = `${data.email} has admin privileges`
            return admin.auth().setCustomUserClaims(user.uid, {admin: true});
        }else{
            message = `${data.email} doesn't have admin privileges`
            return admin.auth().setCustomUserClaims(user.uid, {admin: false});
        }
    }).then(()=>{
        return{ message }
    }).catch(error=>{
        return error;
    })
})


exports.sendNotifications = functions.firestore.document('messages/{messageId}').onCreate(
    async (snapshot) => {
        const text = snapshot.data().text;
        const payload = {
            notification:{
                title: `${snapshot.data().name} posted a message`,
                body: text? (text.length <= 100 ? text: text.substring(0, 97) + '...') : '',
                icon: snapshot.data().profilePicUrl || '/images/blank.png',
                click_action: `https://${process.env.GCLOUD_PROJECT}.firebaseapp.com`,
            }
        };

        //Get the list of device tokens.
        const allTokens = await admin.firestore().collection('fcmTokens').get();
        const tokens = [];
        allTokens.forEach((tokenDoc)=>{tokens.push(tokenDoc.id);
        });

        if (tokens.length > 0) {
            const response = await admin.messaging().sendToDevice(tokens, payload);
            await cleanupTokens(response, tokens);
            console.log('Notifications have been sent and tokens cleaned up.');
        }

    });

    function cleanupTokens(response, tokens){
        //For each notification we check if there was an error.
        const tokensDelete = [];
        response.results.forEach((result, index)=>{
            const error = result.error;
            if (error){
                console.error('Failure sending notification to', tokens[index], error);
                if (error.code === 'messaging/invalid-registration-token' ||
                error.code === 'messaging/registration-token-not-registered'){
                    const deleteTask = admin.firestore().collection('messages').doc(tokens[index]).delete();
                    tokensDelete.push(deleteTask);
                }
            }
        });
        return Promise.all(tokensDelete);
    }




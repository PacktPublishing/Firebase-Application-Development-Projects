

//get the users display pic
const getProfilePicUrl = () => {
    return auth.currentUser.photoURL || '/images/blank.png';
}


//get a handle on the form
const createMessage = document.querySelector('#chat-form');
createMessage.addEventListener('submit', (e)=>{
    e.preventDefault();
    e.stopPropagation();
    console.log(createMessage.message.value);
    saveMessage(createMessage['message'].value);
    createMessage.reset();
})

//save messages to the firestore
const saveMessage = (messageText) => {
    return fs.collection('messages').add({
        name: auth.currentUser.displayName,
        text: messageText,
        profilePicUrl: getProfilePicUrl(),
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
    }).catch(error =>{
        console.log('Error writing new message to firestore', error);
    })
}


//container that will hold the messages
const messageList = document.querySelector('#chat');

const setupMessages = (data)=>{
    if(data.length){
        let html = '';
        data.forEach(doc =>{
            const message = doc.data();

            const div =`
            
            <div class="message-container style="bottom-margin:10px">
                <div class="row">
                    <div class="profile-picture col s2">
                    <img src="${message.profilePicUrl}"
                    style="border-radius:50%; width:50px; height:50px;"/>
                    </div>

                    <div class="chat-message col s10">
                    <div><p style="font-size: 1.5em">${message.text}</p></div>
                    <div><p style="font-size: 0.8em; font-style: oblique;">${message.name}</p></div>
                    </div><hr>

                    </div>
                </div>          
            `;
            html += div;

        })
        messageList.innerHTML = html;
    }
}

//Request permission to show notifications
const requestNotificationsPermissions = () => {
    firebase.messaging().requestPermission().then(()=>{
        saveMessagingDeviceToken();
    }).catch(error => {
        console.log('Unable to get permission to notify:', error);
    });
}

//Save the messaging device token to the datastore
const saveMessagingDeviceToken = () => {
    firebase.messaging().getToken().then(currentToken =>{
        if(currentToken){
            console.log('Got FCM device token:', currentToken);

            firebase.firestore().collection('fcmTokens').doc(currentToken)
            .set({uid: auth.currentUser.uid});
        }else{
            requestNotificationsPermissions()
        }
    }).catch(error => {
        console.log('Unable to get messaging token:', error);
    });
}
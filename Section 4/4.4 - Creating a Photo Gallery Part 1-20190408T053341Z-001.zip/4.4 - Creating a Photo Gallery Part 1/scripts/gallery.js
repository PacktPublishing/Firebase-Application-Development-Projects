//function to store image data in the firestore
const storeImages = (user, url, fileName)=>{
    fs.collection('galleryUploads').add({
        imageUrl: `${url}`,
        uploadedBy: `${user.displayName}`,
        fileName: `galleryUploads/${fileName}`,
    }).then(()=>{
        console.log('image data added to the firestore');
    }).catch(error=>{
        console.log("Error uploading image data:", error);
    })
}


//handle uploaded files
const uploadedFile = document.querySelector('#galleryFile');
uploadedFile.addEventListener('change', (e)=>{
    e.stopPropagation();
    e.preventDefault();
    const file = e.target.files[0];
    console.log(file);
    const metadata = {'contentType': file.type};

})




